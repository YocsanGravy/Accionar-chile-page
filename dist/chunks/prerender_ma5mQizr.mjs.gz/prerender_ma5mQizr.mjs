import { jsx, jsxs } from 'react/jsx-runtime';
import React, { useEffect, useState, useRef, useMemo } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { c as createAstro, a as createComponent, r as renderTemplate, b as addAttribute, d as renderComponent, e as renderHead, f as renderSlot, m as maybeRenderHead } from './astro_C-9UdQ9D.mjs';
import 'kleur/colors';
import 'html-escaper';
import styled from '@emotion/styled';
import { css, keyframes, Global } from '@emotion/react';
import 'clsx';
import react from '@vitejs/plugin-react';
import { version } from 'react-dom';
import CompressionPlugin from 'vite-plugin-compression';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z, ZodError } from 'zod';
import { EnumChangefreq, SitemapAndIndexStream, SitemapStream } from 'sitemap';
import { createWriteStream } from 'fs';
import { resolve, normalize } from 'path';
import { Readable, pipeline } from 'stream';
import { promisify } from 'util';
import { mkdir } from 'fs/promises';
import replace from 'stream-replace-string';
import { Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
/* empty css                         */
import { useForm } from 'react-hook-form';

if (typeof process !== "undefined") {
  let proc = process;
  if ("argv" in proc && Array.isArray(proc.argv)) {
    if (proc.argv.includes("--verbose")) ; else if (proc.argv.includes("--silent")) ; else ;
  }
}

const Breakpoints = {
  base: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1440,
  xxxl: 1920
};
const MediaQuery = {
  /**
   *
   * @param breakpoint MediaQuery.min("md")
   * @returns @media (min-width: 768px)
   */
  min: (breakpoint) => `@media (min-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param breakpoint MediaQuery.max("lg")
   * @returns @media (max-width: 991px)
   */
  max: (breakpoint) => `@media (max-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param minBreakpoint MediaQuery.between("md", "lg")
   * @returns @media (min-width: 768px) and (max-width: 991px)
   */
  between: (minBreakpoint, maxBreakpoint) => `@media (min-width: ${Breakpoints[minBreakpoint]}px) and (max-width: ${Breakpoints[maxBreakpoint]}px)`
};

const StyledContainer = styled.div`
    margin: 0 auto;
    padding: 0 20px;
    width: 100%;

    max-width: 540px;

    ${MediaQuery.between("md", "lg")} {
        max-width: 720px;
    }

    ${MediaQuery.between("lg", "xl")} {
        max-width: 960px;
    }

    ${MediaQuery.between("xl", "xxl")} {
        max-width: 1140px;
    }

    ${MediaQuery.min("xxl")} {
        max-width: 1320px;
    }
`;

const Container = ({ children, ...rest }) => {
  return /* @__PURE__ */ jsx(StyledContainer, { ...rest, children });
};

const ThemeVar = css`
    :root {
        --primary: ${"#FFFFFF" /* primary */};
        --secondary: ${"#20222e" /* secondary */};
        --tertiary: ${"#ff8601" /* tertiary */};

        --bg-element: ${"#FFFFFF" /* bgElement */};
        --text-default: ${"#101118" /* textDefault */};
        --text-secondary: ${"#2f3561" /* textSecondary */};
    }
`;
const Theme = {
  primary: "var(--primary)",
  secondary: "var(--secondary)",
  tertiary: "var(--tertiary)",
  bgElement: "var(--bg-element)",
  textDefault: "var(--text-default)",
  textSecondary: "var(--text-secondary)"
};

const ContentSectionStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
const ContentSectionWrapper = styled.div`
    text-align: center;

    h3,
    h4,
    h5 {
        margin-bottom: 70px;
        font-weight: 200;
    }

    figure {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;

        position: relative;

        &::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            background: linear-gradient(
                0deg,
                ${Theme.primary} 0%,
                ${Theme.tertiary} 100%
            );

            filter: blur(100px);
            opacity: 0.7;
            z-index: -1;
        }

        &,
        img {
            border-radius: 10px;

            width: 100%;
            height: auto;
            object-fit: cover;
            max-width: 970px;
            margin: 0 auto;
        }
    }
`;

const ContentSection = ({
  children,
  ...rest
}) => {
  if (!children)
    return null;
  return /* @__PURE__ */ jsx(ContentSectionStyled, { ...rest, children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(ContentSectionWrapper, { children }) }) });
};

const RobotoBlack = "/_astro/Roboto-Black.tBYbbWl-.woff2";

const RobotoBlackItalic = "/_astro/Roboto-BlackItalic.CxCOE_MU.woff2";

const RobotoBold = "/_astro/Roboto-Bold.OBUL28o9.woff2";

const RobotoBoldItalic = "/_astro/Roboto-BoldItalic.Bbs8lVH2.woff2";

const RobotoItalic = "/_astro/Roboto-Italic.0KLjOP-5.woff2";

const RobotoLight = "/_astro/Roboto-Light.-TzFADkf.woff2";

const RobotoLightItalic = "/_astro/Roboto-LightItalic.DuFP9W7P.woff2";

const RobotoMedium = "/_astro/Roboto-Medium.DRylU_ql.woff2";

const RobotoMediumItalic = "/_astro/Roboto-MediumItalic.CPqftbAj.woff2";

const RobotoRegular = "/_astro/Roboto-Regular.CjbfJjO0.woff2";

const RobotoThin = "/_astro/Roboto-Thin.Df4ydPom.woff2";

const RobotoThinItalic = "/_astro/Roboto-ThinItalic.CI9JpB2v.woff2";

var Fonts = /* @__PURE__ */ ((Fonts2) => {
  Fonts2["primary"] = `"Roboto", sans-serif`;
  return Fonts2;
})(Fonts || {});
const FontFace = css`
    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 100;
        src: url(${RobotoThin}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 300;
        src: url(${RobotoLight}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 400;
        src: url(${RobotoRegular}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 500;
        src: url(${RobotoMedium}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 700;
        src: url(${RobotoBold}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 900;
        src: url(${RobotoBlack}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    // italic
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 100;
        src: url(${RobotoThinItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 300;
        src: url(${RobotoLightItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 400;
        src: url(${RobotoItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 500;
        src: url(${RobotoMediumItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 700;
        src: url(${RobotoBoldItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 900;
        src: url(${RobotoBlackItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
`;

const NormalizeCSS = css`
    ${FontFace};
    ${ThemeVar};

    :root {
        color-scheme: light only;
    }

    body,
    html {
        font-family: ${Fonts.primary};
        font-weight: 400;
        font-size: 16px;
        line-height: 1.5;
    }

    * {
        box-sizing: border-box;
    }

    html {
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
    }

    body {
        margin: 0;

        color: ${Theme.textDefault};
        background: ${Theme.primary};
    }

    main {
        display: block;
    }

    a {
        background-color: transparent;
    }

    abbr[title] {
        border-bottom: none;
        text-decoration: underline;
        text-decoration: underline dotted;
    }

    img {
        border-style: none;
        object-fit: cover;
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-family: inherit; /* 1 */
        font-size: 100%; /* 1 */
        line-height: 1.15; /* 1 */
        margin: 0; /* 2 */
    }

    button,
    [type="button"],
    [type="reset"],
    [type="submit"] {
        -webkit-appearance: button;
    }

    button::-moz-focus-inner,
    [type="button"]::-moz-focus-inner,
    [type="reset"]::-moz-focus-inner,
    [type="submit"]::-moz-focus-inner {
        border-style: none;
        padding: 0;
    }

    button {
        padding: 0;
    }

    figure {
        margin: 0;
        line-height: 0;
    }

    strong {
        font-weight: 700;
    }

    a {
        text-decoration: none;
        color: inherit;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        margin: 0 0 30px;

        &:last-child {
            margin: 0;
        }
    }

    h1 {
        font-size: 50px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
        }
    }

    h2 {
        font-size: 45px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 35px;
        }
    }

    h3 {
        font-size: 35px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 30px;
        }
    }

    h4 {
        font-size: 25px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 25px;
        }
    }

    h5 {
        font-size: 20px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
        }
    }

    h6 {
        font-size: 18px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 15px;
        }
    }

    p {
        margin: 0 0 10px;
        font-size: 16px;
        line-height: 25px;
        letter-spacing: 1px;
        color: ${Theme.textSecondary};

        &:last-child {
            margin: 0;
        }
    }

    b {
        color: ${Theme.tertiary};
    }
`;

const HeroImg = new Proxy({"src":"/_astro/hero-img.kWcJL5yF.webp","width":6000,"height":4000,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/hero-img.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/hero-img.webp");
							return target[name];
						}
					});

const Chart = new Proxy({"src":"/_astro/chart.ByZTC857.webp","width":600,"height":297,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/chart.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/chart.webp");
							return target[name];
						}
					});

const Logo$2 = new Proxy({"src":"/_astro/logo.-9rNAi2N.webp","width":398,"height":439,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/logo.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/logo.webp");
							return target[name];
						}
					});

const PreviewPng = new Proxy({"src":"/_astro/preview.DQNpCrLA.webp","width":1458,"height":635,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/preview.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/images/preview.webp");
							return target[name];
						}
					});

const images = {
  preview: PreviewPng,
  heroImg: HeroImg,
  chart: Chart,
  logo: Logo$2
};
const Image = ({
  alt,
  srcLocal,
  height,
  width,
  src,
  loading,
  ...rest
}) => {
  if (!srcLocal && !src) {
    throw new Error("srcLocal or src is required");
  }
  const image = srcLocal ? images[srcLocal] : { src, width, height };
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: image.src,
      alt,
      width: width ? width : image.width,
      height: height ? height : image.height,
      loading,
      ...rest
    }
  );
};

const LogoStyled = styled.div`
    position: relative;
    z-index: 3;

    a {
        font-size: 35px;
        line-height: 30px;
        font-weight: 700;
        display: inline-flex;
        position: relative;

        span {
            &:after {
                content: "";
                position: absolute;
                bottom: -5px;
                left: 0;
                width: 25%;
                height: 3px;
                background-color: ${Theme.primary};
                z-index: 1;
                transition: width 0.2s linear;
            }
        }

        &:hover span:after {
            width: 100%;
        }

        img {
            height: 50px;
            width: 63px;
            object-fit: contain;
        }
    }
`;

const Logo$1 = () => {
  return /* @__PURE__ */ jsx(LogoStyled, { children: /* @__PURE__ */ jsx("a", { href: "/", children: /* @__PURE__ */ jsx(Image, { srcLocal: "logo", alt: "logo" }) }) });
};

const HeaderAnimationKeyframe = keyframes`
    from {
        transform: translateY(-50px);
        opacity: 0.01;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
`;
const HeaderStyled = styled.header`
    width: 100%;

    background: ${Theme.bgElement};

    padding: 20px 0;

    display: flex;

    justify-content: space-between;
    align-items: center;

    gap: 40px;

    position: sticky;
    top: 0;
    left: 0;
    z-index: 10;

    box-shadow: 0 0 10px rgb(123 123 123 / 10%);

    animation: ${HeaderAnimationKeyframe} 1s;
`;
const ContainerStyled$1 = styled(Container)`
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 40px;
`;

const SocialsStyled = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;

    margin: 20px 0 0;
`;
const SocialsList = styled.ul`
    display: flex;
    gap: 10px;
    list-style-type: none;
    align-items: center;
    justify-content: center;
    padding: 0;
    margin: 0;
`;
const SocialsListItem = styled.li`
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;

    cursor: pointer;
    transition: 0.3s;
    opacity: 0.5;

    &:hover {
        opacity: 1;
    }

    &:not(:last-of-type) {
        &:after {
            content: "";
            display: block;
            width: 1px;
            height: 20px;
            background-color: ${Theme.textSecondary};
            margin: 0 10px;
        }
    }
`;
const SocialsLink = styled.a`
    text-decoration: none;
    color: inherit;

    img {
        width: 20px;
        height: 20px;
        aspect-ratio: 20/20;
        object-fit: contain;
    }
`;

const IconFacebook = new Proxy({"src":"/_astro/icon-facebook.DsGzXVu6.svg","width":15,"height":32,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-facebook.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-facebook.svg");
							return target[name];
						}
					});

const IconInstagram = new Proxy({"src":"/_astro/icon-instagram.sLmx2nSf.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-instagram.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-instagram.svg");
							return target[name];
						}
					});

const IconTwitter = new Proxy({"src":"/_astro/icon-twitter.DTC1fYlL.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-twitter.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-twitter.svg");
							return target[name];
						}
					});

const IconLinkedIn = new Proxy({"src":"/_astro/icon-linkedin.BhLvCzM5.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-linkedin.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-linkedin.svg");
							return target[name];
						}
					});

const IconArrowDown = new Proxy({"src":"/_astro/icon-arrow-down.nKso-wJB.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-arrow-down.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-arrow-down.svg");
							return target[name];
						}
					});

const IconArrowCircle = new Proxy({"src":"/_astro/icon-arrow-circle.BMdIuAa2.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-arrow-circle.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-arrow-circle.svg");
							return target[name];
						}
					});

const IconAstro = new Proxy({"src":"/_astro/icon-astro.BbG368WH.svg","width":1333,"height":432,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-astro.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/Users/jajajajja/Desktop/Accionar-chile-page/src/static/icons/icon-astro.svg");
							return target[name];
						}
					});

const icons = {
  arrowDown: IconArrowDown,
  arrowCircle: IconArrowCircle,
  facebook: IconFacebook,
  instagram: IconInstagram,
  twitter: IconTwitter,
  linkedin: IconLinkedIn,
  astro: IconAstro
};
const Icon = ({ alt, iconData, ...rest }) => {
  const icon = icons[iconData];
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: icon.src,
      alt,
      width: icon.width,
      height: icon.height,
      "data-icon": "true",
      ...rest
    }
  );
};

const Socials = ({ ...rest }) => {
  return /* @__PURE__ */ jsx(SocialsStyled, { ...rest, children: /* @__PURE__ */ jsxs(SocialsList, { children: [
    /* @__PURE__ */ jsx(SocialsListItem, { children: /* @__PURE__ */ jsx(
      SocialsLink,
      {
        href: "https://www.facebook.com",
        target: "_blank",
        rel: "noreferrer",
        children: /* @__PURE__ */ jsx(Icon, { iconData: "facebook", alt: "facebook" })
      }
    ) }),
    /* @__PURE__ */ jsx(SocialsListItem, { children: /* @__PURE__ */ jsx(
      SocialsLink,
      {
        href: "https://www.linkedin.com",
        target: "_blank",
        rel: "noreferrer",
        children: /* @__PURE__ */ jsx(Icon, { iconData: "linkedin", alt: "linkedin" })
      }
    ) })
  ] }) });
};

const NavigationStyled = styled.div`
    display: flex;
    gap: 50px;

    ${MediaQuery.max("xl")} {
        gap: 20px;
    }
`;
const NavigationListWrapper = styled.nav`
    display: flex;
    align-items: center;
    justify-content: center;

    ${MediaQuery.max("lg")} {
        position: fixed;
        top: 0;
        right: -100%;

        background: ${Theme.bgElement};
        height: 100vh;
        z-index: 2;
        transform: translateX(100%);
        transition: transform 0.3s linear, right 0.7s;
        padding-top: 85px;

        width: clamp(300px, 80%, 300px);

        ${({ $isOpen }) => $isOpen && css`
                right: 0;
                transform: translateX(0);
            `};
    }
`;
const NavigationList = styled.ul`
    padding: 0;
    margin: 0;
    list-style-type: none;
    display: flex;

    ${MediaQuery.min("lg")} {
        gap: 20px;
        align-items: center;
        justify-content: center;
    }

    ${MediaQuery.max("lg")} {
        gap: 10px;
        padding: 20px 10px 53px;
        overflow: auto;
        width: 100%;
        height: 100%;

        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
    }

    > li a {
        text-decoration: none;
        color: ${Theme.textDefault};
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        line-height: 18px;
        padding: 10px;
        border-radius: 5px;
        background-color: transparent;
        cursor: pointer;
        transition: background-color 0.2s linear;

        ${MediaQuery.max("lg")} {
            padding: 10px 20px;
        }

        &:hover {
            background-color: ${Theme.tertiary};
            color: ${Theme.primary};
        }

        &.active:not(:hover) {
            background-color: ${Theme.tertiary};
            color: ${Theme.primary};
        }
        img {
            margin: 0 15px 0 0;

            max-width: 30px;
            max-height: 30px;

            ${MediaQuery.max("xl")} {
                margin: 0 10px 0 0;
            }
        }
    }
`;
styled(Socials)`
    position: absolute;
    bottom: 0;
    background: ${Theme.bgElement};
    width: 100%;
    padding: 10px 0;
    margin: 0;
    left: 0;

    li {
        opacity: 1;
    }

    ${MediaQuery.min("lg")} {
        display: none;
    }
`;

const HamburgerMenuButton = styled.button`
    position: relative;
    z-index: 3;

    border: 1px solid ${Theme.tertiary};
    border-radius: 50%;
    background: ${Theme.bgElement};
    cursor: pointer;
    transition: background 0.3s, border-color 0.3s, color 0.3s;

    width: 45px;
    height: 45px;

    ${MediaQuery.min("lg")} {
        display: none;
    }
`;
const HamburgerMenuButtonLine = styled.span`
    background: ${Theme.tertiary};
    position: absolute;
    left: 50%;
    display: block;
    transform: translate(-50%, -50%);
    transition: transform 0.3s, background 0.3s, top 0.3s;
    pointer-events: none;

    width: 50%;
    height: 3px;

    ${MediaQuery.max("lg")} {
        height: 2px;
    }

    ${({ $open }) => $open ? css`
                  transform: translate(-50%, -50%) rotate(45deg);
                  top: 50%;
              ` : css`
                  top: calc(50% - 4px);
              `}

    &:not(:first-of-type) {
        ${({ $open }) => $open ? css`
                      transform: translate(-49%, -50%) rotate(-45deg);
                      top: 50%;
                  ` : css`
                      top: calc(50% + 4px);
                  `}
    }
`;

const Hamburger = ({ state }) => {
  const { open, setOpen } = state;
  const handleMenu = () => {
    setOpen(!open);
  };
  const handleClickOutside = (e) => {
    const target = e.target;
    if (!target.closest("nav") && open && target.tagName !== "BUTTON") {
      setOpen(false);
    }
  };
  useEffect(() => {
    if (!open)
      return;
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [open]);
  return /* @__PURE__ */ jsxs(
    HamburgerMenuButton,
    {
      $open: open,
      onClick: handleMenu,
      "aria-label": "Menu",
      "aria-expanded": open,
      role: "button",
      tabIndex: 0,
      children: [
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open }),
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open })
      ]
    }
  );
};

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  return /* @__PURE__ */ jsxs(NavigationStyled, { children: [
    /* @__PURE__ */ jsx(NavigationListWrapper, { $isOpen: isOpen, children: /* @__PURE__ */ jsxs(NavigationList, { children: [
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/", children: "Hogar" }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/offers", className: "active", children: "Sinergeticos" }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/about", children: "Sobre Nosotros" }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/contact", children: "Contacto" }) })
    ] }) }),
    /* @__PURE__ */ jsx(
      Hamburger,
      {
        state: {
          open: isOpen,
          setOpen: setIsOpen
        }
      }
    )
  ] });
};

const Header = () => {
  return /* @__PURE__ */ jsx(HeaderStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled$1, { children: [
    /* @__PURE__ */ jsx(Logo$1, {}),
    /* @__PURE__ */ jsx(Navigation, {})
  ] }) });
};

const FooterStyled = styled.footer`
    width: 100%;

    background: ${Theme.bgElement};

    box-shadow: 0 0 10px rgb(123 123 123 / 10%);
    padding: 0 0 50px;
    margin-top: 200px;

    ${MediaQuery.max("lg")} {
        margin-top: 100px;
    }
`;
const FooterContainer = styled.div`
    display: flex;
    justify-content: space-between;

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        gap: 20px;
        justify-content: center;
        align-items: center;
    }
`;
const FooterContent = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        text-align: center;
    }

    p {
        margin: 0;
    }
`;

const FormStyled = styled.form`
    padding: 30px;
    background: ${Theme.bgElement};
    border-radius: 10px;
    box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);
    width: 100%;

    h2 {
        font-size: 30px;
        line-height: 36px;
        font-weight: 300;
        margin-bottom: 10px;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
            line-height: 25px;
        }
    }

    p {
        opacity: 0.8;

        ${MediaQuery.max("lg")} {
            font-size: 14px;
            line-height: 16px;
        }
    }
`;

styled.div`
    background: ${Theme.bgElement};
    transform: translateY(-50%);

    ${MediaQuery.max("lg")} {
        transform: translateY(-20%);
    }
`;
styled.div``;
styled(FormStyled)``;
styled.div`
    display: grid;
    grid-template-columns: 80% 20%;
    gap: 30px;
    align-items: flex-start;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        gap: 0;
    }
`;
styled.h2`
    padding: 20px;
    max-width: 800px;
    margin: 0 auto !important;
    box-shadow: 0 0 30px ${Theme.tertiary};

    ${MediaQuery.max("lg")} {
        font-size: 25px;
        line-height: 30px;
        max-width: 400px;
    }
`;

const defaultInputStyles = css`
    padding: 10px 0;
    border: none;
    width: 100%;
    margin-bottom: 10px;
    box-sizing: border-box;
    background: transparent;
    border-bottom: 1px solid ${Theme.textSecondary};
    transition: border-color 0.3s;
    letter-spacing: 1px;
    color: ${Theme.textDefault};
    margin: 30px 0;

    ${MediaQuery.max("lg")} {
        margin-bottom: 0;
    }

    &:focus,
    &:active {
        outline: none;
        border-color: ${Theme.tertiary};
    }

    &::placeholder {
        color: ${Theme.textSecondary};
    }
`;
const InputWrapper = styled.div``;
const InputStyled = styled.input`
    ${defaultInputStyles}
`;
const InputTextAreaStyled = styled.textarea`
    ${defaultInputStyles};

    resize: none;
    min-height: 90px;
`;

const Input = ({
  placeholder,
  type,
  register,
  error,
  ...rest
}) => {
  const InputComponent = type === "textarea" ? InputTextAreaStyled : InputStyled;
  return /* @__PURE__ */ jsxs(InputWrapper, { children: [
    /* @__PURE__ */ jsx(InputComponent, { placeholder, ...register, ...rest }),
    error && /* @__PURE__ */ jsx("p", { children: error })
  ] });
};

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: ${({ $align }) => $align || "flex-start"};
    margin-top: 20px;
`;
const ButtonLink = styled.a`
    text-transform: uppercase;
    transition: 0.3s;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    text-align: center;

    ${({ $variant }) => $variant === "primary" && PrimaryVariant};
    ${({ $variant }) => $variant === "secondary" && SecondaryVariant};
`;
const Button$1 = ButtonLink.withComponent("button");
const PrimaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.textDefault};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: transparent;
    color: ${Theme.textDefault};

    &:hover {
        background: ${Theme.textDefault};
        color: ${Theme.primary};
    }
`;
const SecondaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.tertiary};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: ${Theme.tertiary};
    color: ${Theme.primary};

    &:hover {
        background: transparent;
        color: ${Theme.tertiary};
    }
`;

const Button = ({
  link,
  target,
  children,
  align,
  variant = "primary",
  asButton,
  type,
  ...rest
}) => {
  const ButtonComponent = asButton ? Button$1 : ButtonLink;
  return /* @__PURE__ */ jsx(ButtonWrapper, { $align: align, children: /* @__PURE__ */ jsx(
    ButtonComponent,
    {
      href: link,
      target,
      ...rest,
      $variant: variant,
      children
    }
  ) });
};

const FadeInStyled = styled.div`
    opacity: 0.001;
    transform: translateY(20px);
    transition: opacity 0.5s, transform 0.5s;

    &.visible {
        opacity: 1;
        transform: translateY(0);
    }
`;

const FadeIn = ({ children, delay }) => {
  const elementRef = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          } else {
            entry.target.classList.remove("visible");
          }
        });
      },
      {
        root: null,
        rootMargin: "-50px",
        threshold: 0.1
      }
    );
    if (elementRef.current) {
      observer.observe(elementRef.current);
    }
    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, []);
  return /* @__PURE__ */ jsx(FadeInStyled, { ref: elementRef, children });
};

const Footer = () => {
  return /* @__PURE__ */ jsx(FooterStyled, { children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs(FooterContainer, { children: [
    /* @__PURE__ */ jsx(Logo$1, {}),
    /* @__PURE__ */ jsx(FooterContent, { children: /* @__PURE__ */ jsx("p", { children: "© 2025 Todos los derechos reservados a Accionar Chile" }) }),
    /* @__PURE__ */ jsx(Socials, {})
  ] }) }) });
};

function defineConfig(config) {
  return config;
}

const FAST_REFRESH_PREAMBLE = react.preambleCode;
function getRenderer() {
  return {
    name: "@astrojs/react",
    clientEntrypoint: version.startsWith("18.") ? "@astrojs/react/client.js" : "@astrojs/react/client-v17.js",
    serverEntrypoint: version.startsWith("18.") ? "@astrojs/react/server.js" : "@astrojs/react/server-v17.js"
  };
}
function optionsPlugin(experimentalReactChildren) {
  const virtualModule = "astro:react:opts";
  const virtualModuleId = "\0" + virtualModule;
  return {
    name: "@astrojs/react:opts",
    resolveId(id) {
      if (id === virtualModule) {
        return virtualModuleId;
      }
    },
    load(id) {
      if (id === virtualModuleId) {
        return {
          code: `export default {
						experimentalReactChildren: ${JSON.stringify(experimentalReactChildren)}
					}`
        };
      }
    }
  };
}
function getViteConfiguration({
  include,
  exclude,
  experimentalReactChildren
} = {}) {
  return {
    optimizeDeps: {
      include: [
        version.startsWith("18.") ? "@astrojs/react/client.js" : "@astrojs/react/client-v17.js",
        "react",
        "react/jsx-runtime",
        "react/jsx-dev-runtime",
        "react-dom"
      ],
      exclude: [
        version.startsWith("18.") ? "@astrojs/react/server.js" : "@astrojs/react/server-v17.js"
      ]
    },
    plugins: [react({ include, exclude }), optionsPlugin(!!experimentalReactChildren)],
    resolve: {
      dedupe: ["react", "react-dom", "react-dom/server"]
    },
    ssr: {
      external: version.startsWith("18.") ? ["react-dom/server", "react-dom/client"] : ["react-dom/server.js", "react-dom/client.js"],
      noExternal: [
        // These are all needed to get mui to work.
        "@mui/material",
        "@mui/base",
        "@babel/runtime",
        "redoc",
        "use-immer"
      ]
    }
  };
}
function src_default$1({
  include,
  exclude,
  experimentalReactChildren
} = {}) {
  return {
    name: "@astrojs/react",
    hooks: {
      "astro:config:setup": ({ command, addRenderer, updateConfig, injectScript }) => {
        addRenderer(getRenderer());
        updateConfig({
          vite: getViteConfiguration({ include, exclude, experimentalReactChildren })
        });
        if (command === "dev") {
          const preamble = FAST_REFRESH_PREAMBLE.replace(`__BASE__`, "/");
          injectScript("before-hydration", preamble);
        }
      }
    }
  };
}

function parseI18nUrl(url, defaultLocale, locales, base) {
  if (!url.startsWith(base)) {
    return void 0;
  }
  let s = url.slice(base.length);
  if (!s || s === "/") {
    return { locale: defaultLocale, path: "/" };
  }
  if (s[0] !== "/") {
    s = "/" + s;
  }
  const locale = s.split("/")[1];
  if (locale in locales) {
    let path = s.slice(1 + locale.length);
    if (!path) {
      path = "/";
    }
    return { locale, path };
  }
  return { locale: defaultLocale, path: s };
}

function generateSitemap(pages, finalSiteUrl, opts) {
  const { changefreq, priority, lastmod: lastmodSrc, i18n } = opts ?? {};
  const urls = [...pages];
  urls.sort((a, b) => a.localeCompare(b, "en", { numeric: true }));
  const lastmod = lastmodSrc?.toISOString();
  const { defaultLocale, locales } = i18n ?? {};
  let getI18nLinks;
  if (defaultLocale && locales) {
    getI18nLinks = createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl);
  }
  const urlData = urls.map((url, i) => ({
    url,
    links: getI18nLinks?.(i),
    lastmod,
    priority,
    changefreq
  }));
  return urlData;
}
function createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl) {
  const parsedI18nUrls = urls.map((url) => parseI18nUrl(url, defaultLocale, locales, finalSiteUrl));
  const i18nPathToLinksCache = /* @__PURE__ */ new Map();
  return (urlIndex) => {
    const i18nUrl = parsedI18nUrls[urlIndex];
    if (!i18nUrl) {
      return void 0;
    }
    const cached = i18nPathToLinksCache.get(i18nUrl.path);
    if (cached) {
      return cached;
    }
    const links = [];
    for (let i = 0; i < parsedI18nUrls.length; i++) {
      const parsed = parsedI18nUrls[i];
      if (parsed?.path === i18nUrl.path) {
        links.push({
          url: urls[i],
          lang: locales[parsed.locale]
        });
      }
    }
    if (links.length <= 1) {
      return void 0;
    }
    i18nPathToLinksCache.set(i18nUrl.path, links);
    return links;
  };
}

const SITEMAP_CONFIG_DEFAULTS = {
  entryLimit: 45e3
};

const localeKeySchema = z.string().min(1);
const SitemapOptionsSchema = z.object({
  filter: z.function().args(z.string()).returns(z.boolean()).optional(),
  customPages: z.string().url().array().optional(),
  canonicalURL: z.string().url().optional(),
  i18n: z.object({
    defaultLocale: localeKeySchema,
    locales: z.record(
      localeKeySchema,
      z.string().min(2).regex(/^[a-zA-Z\-]+$/gm, {
        message: "Only English alphabet symbols and hyphen allowed"
      })
    )
  }).refine((val) => !val || val.locales[val.defaultLocale], {
    message: "`defaultLocale` must exist in `locales` keys"
  }).optional(),
  entryLimit: z.number().nonnegative().optional().default(SITEMAP_CONFIG_DEFAULTS.entryLimit),
  serialize: z.function().args(z.any()).returns(z.any()).optional(),
  changefreq: z.nativeEnum(EnumChangefreq).optional(),
  lastmod: z.date().optional(),
  priority: z.number().min(0).max(1).optional()
}).strict().default(SITEMAP_CONFIG_DEFAULTS);

const validateOptions = (site, opts) => {
  const result = SitemapOptionsSchema.parse(opts);
  z.object({
    site: z.string().optional(),
    // Astro takes care of `site`: how to validate, transform and refine
    canonicalURL: z.string().optional()
    // `canonicalURL` is already validated in prev step
  }).refine((options) => options.site || options.canonicalURL, {
    message: "Required `site` astro.config option or `canonicalURL` integration option"
  }).parse({
    site,
    canonicalURL: result.canonicalURL
  });
  return result;
};

async function writeSitemap({
  hostname,
  sitemapHostname = hostname,
  sourceData,
  destinationDir,
  limit = 5e4,
  publicBasePath = "./"
}, astroConfig) {
  await mkdir(destinationDir, { recursive: true });
  const sitemapAndIndexStream = new SitemapAndIndexStream({
    limit,
    getSitemapStream: (i) => {
      const sitemapStream = new SitemapStream({
        hostname
      });
      const path = `./sitemap-${i}.xml`;
      const writePath = resolve(destinationDir, path);
      if (!publicBasePath.endsWith("/")) {
        publicBasePath += "/";
      }
      const publicPath = normalize(publicBasePath + path);
      let stream;
      if (astroConfig.trailingSlash === "never" || astroConfig.build.format === "file") {
        const host = hostname.endsWith("/") ? hostname.slice(0, -1) : hostname;
        const searchStr = `<loc>${host}/</loc>`;
        const replaceStr = `<loc>${host}</loc>`;
        stream = sitemapStream.pipe(replace(searchStr, replaceStr)).pipe(createWriteStream(writePath));
      } else {
        stream = sitemapStream.pipe(createWriteStream(writePath));
      }
      return [new URL(publicPath, sitemapHostname).toString(), sitemapStream, stream];
    }
  });
  let src = Readable.from(sourceData);
  const indexPath = resolve(destinationDir, `./sitemap-index.xml`);
  return promisify(pipeline)(src, sitemapAndIndexStream, createWriteStream(indexPath));
}

function formatConfigErrorMessage(err) {
  const errorList = err.issues.map((issue) => ` ${issue.path.join(".")}  ${issue.message + "."}`);
  return errorList.join("\n");
}
const PKG_NAME = "@astrojs/sitemap";
const OUTFILE = "sitemap-index.xml";
const STATUS_CODE_PAGES = /* @__PURE__ */ new Set(["404", "500"]);
function isStatusCodePage(pathname) {
  if (pathname.endsWith("/")) {
    pathname = pathname.slice(0, -1);
  }
  const end = pathname.split("/").pop() ?? "";
  return STATUS_CODE_PAGES.has(end);
}
const createPlugin = (options) => {
  let config;
  return {
    name: PKG_NAME,
    hooks: {
      "astro:config:done": async ({ config: cfg }) => {
        config = cfg;
      },
      "astro:build:done": async ({ dir, routes, pages, logger }) => {
        try {
          if (!config.site) {
            logger.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          const opts = validateOptions(config.site, options);
          const { filter, customPages, serialize, entryLimit } = opts;
          let finalSiteUrl;
          if (config.site) {
            finalSiteUrl = new URL(config.base, config.site);
          } else {
            console.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          let pageUrls = pages.filter((p) => !isStatusCodePage(p.pathname)).map((p) => {
            if (p.pathname !== "" && !finalSiteUrl.pathname.endsWith("/"))
              finalSiteUrl.pathname += "/";
            if (p.pathname.startsWith("/"))
              p.pathname = p.pathname.slice(1);
            const fullPath = finalSiteUrl.pathname + p.pathname;
            return new URL(fullPath, finalSiteUrl).href;
          });
          let routeUrls = routes.reduce((urls, r) => {
            if (r.type !== "page")
              return urls;
            if (r.pathname) {
              if (isStatusCodePage(r.pathname ?? r.route))
                return urls;
              let fullPath = finalSiteUrl.pathname;
              if (fullPath.endsWith("/"))
                fullPath += r.generate(r.pathname).substring(1);
              else
                fullPath += r.generate(r.pathname);
              let newUrl = new URL(fullPath, finalSiteUrl).href;
              if (config.trailingSlash === "never") {
                urls.push(newUrl);
              } else if (config.build.format === "directory" && !newUrl.endsWith("/")) {
                urls.push(newUrl + "/");
              } else {
                urls.push(newUrl);
              }
            }
            return urls;
          }, []);
          pageUrls = Array.from(/* @__PURE__ */ new Set([...pageUrls, ...routeUrls, ...customPages ?? []]));
          try {
            if (filter) {
              pageUrls = pageUrls.filter(filter);
            }
          } catch (err) {
            logger.error(`Error filtering pages
${err.toString()}`);
            return;
          }
          if (pageUrls.length === 0) {
            logger.warn(`No pages found!
\`${OUTFILE}\` not created.`);
            return;
          }
          let urlData = generateSitemap(pageUrls, finalSiteUrl.href, opts);
          if (serialize) {
            try {
              const serializedUrls = [];
              for (const item of urlData) {
                const serialized = await Promise.resolve(serialize(item));
                if (serialized) {
                  serializedUrls.push(serialized);
                }
              }
              if (serializedUrls.length === 0) {
                logger.warn("No pages found!");
                return;
              }
              urlData = serializedUrls;
            } catch (err) {
              logger.error(`Error serializing pages
${err.toString()}`);
              return;
            }
          }
          const destDir = fileURLToPath(dir);
          await writeSitemap(
            {
              hostname: finalSiteUrl.href,
              destinationDir: destDir,
              publicBasePath: config.base,
              sourceData: urlData,
              limit: entryLimit
            },
            config
          );
          logger.info(`\`${OUTFILE}\` created at \`${path.relative(process.cwd(), destDir)}\``);
        } catch (err) {
          if (err instanceof ZodError) {
            logger.warn(formatConfigErrorMessage(err));
          } else {
            throw err;
          }
        }
      }
    }
  };
};
var src_default = createPlugin;

const siteUrl = "https://agency-aestro-astro.netlify.app";

const date = new Date().toISOString();
// https://astro.build/config
defineConfig({
    site: siteUrl + "/",

    integrations: [
        src_default$1(),
        src_default({
            serialize(item) {
                // Default values for pages
                item.priority = siteUrl + "/" === item.url ? 1.0 : 0.9;
                item.changefreq = "weekly";
                item.lastmod = date;

                // if you want to exclude a page from the sitemap, do it here
                // if (/exclude-from-sitemap/.test(item.url)) {
                //     return undefined;
                // }

                // if any page needs a different priority, changefreq, or lastmod, uncomment the following lines and adjust as needed
                // if (/test-sitemap/.test(item.url)) {
                //     item.changefreq = "daily";
                //     item.lastmod = date;
                //     item.priority = 0.9;
                // }

                // if you want to change priority of all subpages like "/posts/*", you can use:
                // if (/\/posts\//.test(item.url)) {
                //     item.priority = 0.7;
                // }
                return item;
            },
        }),
    ],
    renderers: ["@astrojs/renderer-react"],
    prerender: true,
    vite: {
        plugins: [CompressionPlugin()],
    },
    buildOptions: {
        minify: true,
    },
});

const $$Astro$6 = createAstro("https://agency-aestro-astro.netlify.app/");
const $$MetaConfig = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$MetaConfig;
  const { title, description, preview } = Astro2.props;
  const metaData = {
    keywords: "astro.build, astro, static site, react, webiste templates, website creation, react templates, next.js templates, astro templates, custom website, custom website templates",
    default: {
      url: siteUrl,
      type: "website",
      title,
      description,
      image: preview
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      image: preview,
      domain: siteUrl,
      url: siteUrl
    }
  };
  return renderTemplate`<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><!-- icons --><link rel="icon" type="image/x-icon" href="/favicon.ico"><link rel="apple-touch-icon" sizes="48x48" href="/favicon.ico"><!-- Other meta important things --><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="color-scheme" content="light only"><meta name="keywords"${addAttribute(metaData.keywords, "content")}><meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"><!-- default ones --><meta property="url"${addAttribute(metaData.default.url, "content")}><meta property="type"${addAttribute(metaData.default.type, "content")}><meta property="title"${addAttribute(metaData.default.title, "content")}><meta property="description"${addAttribute(metaData.default.description, "content")}><meta property="image"${addAttribute(metaData.default.image, "content")}><!-- open graph ones --><meta property="og:url"${addAttribute(metaData.default.url, "content")}><meta property="og:type"${addAttribute(metaData.default.type, "content")}><meta property="og:title"${addAttribute(metaData.default.title, "content")}><meta property="og:description"${addAttribute(metaData.default.description, "content")}><meta property="og:image"${addAttribute(metaData.default.image, "content")}><!-- twitter ones --><meta name="twitter:card"${addAttribute(metaData.twitter.card, "content")}><meta name="twitter:title"${addAttribute(metaData.twitter.title, "content")}><meta name="twitter:description"${addAttribute(metaData.twitter.description, "content")}><meta name="twitter:image"${addAttribute(metaData.twitter.image, "content")}><meta property="twitter:domain"${addAttribute(metaData.twitter.domain, "content")}><meta property="twitter:url"${addAttribute(metaData.twitter.url, "content")}>`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/layouts/MetaConfig.astro", void 0);

const $$Astro$5 = createAstro("https://agency-aestro-astro.netlify.app/");
const $$Layout = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title, description, overwritePreview } = Astro2.props;
  return renderTemplate`<html lang="en"> <head>${renderComponent($$result, "MetaConfig", $$MetaConfig, { "title": title, "description": description, "preview": overwritePreview ? overwritePreview : PreviewPng.src })}<title>${title}</title>${renderComponent($$result, "Global", Global, { "styles": NormalizeCSS })}${renderHead()}</head> <body> ${renderComponent($$result, "Header", Header, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Header", "client:component-export": "Header" })} ${renderSlot($$result, $$slots["default"])} ${renderComponent($$result, "Footer", Footer, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@modules/Footer", "client:component-export": "Footer" })} </body></html>`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/layouts/Layout.astro", void 0);

const $$Astro$4 = createAstro("https://agency-aestro-astro.netlify.app/");
const $$404 = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$404;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "404 | Page not found", "description": "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto",
    minHeight: "850px",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Wooops - Soory! 404</h1> <p>
The page you are looking for might have been removed, had
                    its name changed, or is temporarily unavailable.
</p> ${renderComponent($$result4, "Button", Button, { "variant": "secondary", "link": "/", "align": "center" }, { "default": ($$result5) => renderTemplate`
Go back
` })} ` })} ` })} </main> ` })}`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/404.astro", void 0);

const $$file$4 = "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/404.astro";
const $$url$4 = "/404";

const _404 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file$4,
  url: $$url$4
}, Symbol.toStringTag, { value: 'Module' }));

const BoxOffersStyled = styled.section`
    padding: 90px 0;
`;
const BoxOffersWrapper = styled.div`
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: repeat(1, 1fr);
    }

    h2 {
        letter-spacing: 2px;
        margin-bottom: 10px;
    }

    h2 {
        font-size: 35px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 30px;
        }
    }
`;

const TextBotStyed = styled.div`
    padding: 30px;
    border-radius: 10px;
    background: ${Theme.bgElement};

    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 100%;
        background: linear-gradient(
            0deg,
            ${Theme.tertiary} 100%,
            ${Theme.primary} 0%
        );
        filter: blur(30px);
        opacity: 0.1;
        z-index: -1;
        transition: 0.3s opacity;
    }

    ${(props) => props.$variant === "background-text" && TextBoxBackgroundTextVariant}
`;
const TextBoxLinkStyled = styled(TextBotStyed.withComponent("a"))`
    &:hover {
        &:before {
            opacity: 0.6;
        }

        img[data-icon="true"] {
            transform: translate(10px, -10px) scale(1.1);
        }
    }
`;
const TextBotBgText = styled.span`
    position: absolute;
    top: 0;
    right: 0;
    text-transform: uppercase;

    font-size: 90px;
    line-height: 1;
    font-weight: 900;
    letter-spacing: -7px;
    z-index: 1;
    color: ${Theme.primary};
    opacity: 0.5;

    ${MediaQuery.max("xxl")} {
        font-size: 80px;
    }

    ${MediaQuery.max("xl")} {
        font-size: 60px;
        letter-spacing: -3px;
    }
`;
const TextBotTextWrapper = styled.div`
    position: relative;
    z-index: 2;

    ${MediaQuery.max("md")} {
        max-width: 80%;
    }
`;
const TextBoxBackgroundTextVariant = css`
    position: relative;
    overflow: hidden;
    padding: 20px;

    h2,
    h3,
    h4 {
        margin-bottom: 10px;
        font-size: 25px;
        line-height: 1.2;

        &:after {
            content: none;
        }
    }

    h4,
    p {
        position: relative;
        z-index: 2;
    }

    p {
        line-height: 1.2;
    }
`;
const LinkIconFigure = styled.figure`
    display: flex;
    justify-content: flex-end;
    align-items: flex-end;
    width: 100%;
`;
const LinkIcon = styled(Icon)`
    transition: transform 0.3s;
`;

const TextBox = ({
  children,
  variant,
  bgText,
  boxAsLink,
  ...rest
}) => {
  if (!children)
    return null;
  const TextBoxComponent = boxAsLink ? TextBoxLinkStyled : TextBotStyed;
  return /* @__PURE__ */ jsxs(TextBoxComponent, { $variant: variant, ...rest, children: [
    variant === "background-text" && bgText && /* @__PURE__ */ jsx(TextBotBgText, { children: bgText }),
    /* @__PURE__ */ jsx(
      TextBotTextWrapper,
      {
        dangerouslySetInnerHTML: { __html: children }
      }
    ),
    boxAsLink && /* @__PURE__ */ jsx(LinkIconFigure, { children: /* @__PURE__ */ jsx(LinkIcon, { iconData: "arrowCircle", alt: "arrow" }) })
  ] });
};

const BoxOffers = ({ boxes }) => {
  if (!boxes || boxes.length === 0)
    return null;
  return /* @__PURE__ */ jsx(BoxOffersStyled, { children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(BoxOffersWrapper, { children: boxes.map((box, index) => {
    return box.content && /* @__PURE__ */ jsx(FadeIn, { delay: `0.` + index, children: /* @__PURE__ */ jsx(
      TextBox,
      {
        boxAsLink: box.asLink,
        href: box.href,
        children: box.content
      }
    ) }, index);
  }) }) }) });
};

const HeroWrapper = styled.section`
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 90px 0 50px;
    text-align: center;
`;

const CenterTextStyled = styled.div`
    width: 100%;

    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;

    max-width: 650px;
    margin: 0 auto;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        height: 80%;
        background: linear-gradient(
            0deg,
            transparent 0%,
            ${Theme.tertiary} 100%
        );

        filter: blur(100px);
        opacity: 0.3;
        z-index: -1;
    }

    .icon-wrapper {
        margin-top: 50px;
    }
`;

const CenterText = ({ children }) => {
  if (!children)
    return null;
  return /* @__PURE__ */ jsx(CenterTextStyled, { children });
};

const TextImageStyled = styled.div`
    width: 100%;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 50px;
    text-align: left;

    align-items: center;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        text-align: center;
    }

    ${({ $switchPlaces }) => $switchPlaces && css`
            > div:first-of-type {
                order: 2;
            }
        `}
`;
const TextImageFigure = styled.figure`
    width: 100%;
    position: relative;

    &::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 100%;
        border-radius: 100%;
        background: linear-gradient(
            0deg,
            ${Theme.tertiary} 100%,
            ${Theme.primary} 0%
        );

        filter: blur(50px);
        opacity: 0.3;
        z-index: -1;
    }
`;
const TextImage$1 = styled(Image)`
    width: 100%;
    margin-bottom: 30px;
    min-height: 450px;

    object-fit: contain;

    ${MediaQuery.max("lg")} {
        min-height: auto;
    }
`;
const TextImageContent = styled.div`
    ${MediaQuery.max("lg")} {
        max-width: 490px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
    }

    h1 {
        margin-bottom: 20px;
        font-size: 80px;
        line-height: 84px;
        letter-spacing: -1px;

        ${MediaQuery.max("xl")} {
            font-size: 60px;
            line-height: 64px;
        }

        ${MediaQuery.max("sm")} {
            font-size: 50px;
            line-height: 45px;
            letter-spacing: -0.5px;
        }
    }

    p {
        ${MediaQuery.min("lg")} {
            max-width: 400px;
        }
    }
`;
const ButtonsWrapper = styled.div`
    display: flex;

    ${MediaQuery.min("lg")} {
        gap: 30px;
    }

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        align-items: center;
    }
`;

const TextImage = ({
  title,
  paragraph,
  buttons,
  image,
  switchPlaces = false
}) => {
  if (!title && !paragraph && !image) {
    return null;
  }
  const displayImage = image.srcLocal ? /* @__PURE__ */ jsx(
    TextImage$1,
    {
      srcLocal: image.srcLocal,
      alt: image.alt,
      width: image.width,
      height: image.height
    }
  ) : /* @__PURE__ */ jsx(
    TextImage$1,
    {
      src: image.src,
      alt: image.alt,
      width: image.width,
      height: image.height
    }
  );
  return /* @__PURE__ */ jsxs(TextImageStyled, { $switchPlaces: switchPlaces, children: [
    /* @__PURE__ */ jsx(FadeIn, { delay: 0.2, children: /* @__PURE__ */ jsxs(TextImageContent, { children: [
      title && /* @__PURE__ */ jsx("h1", { dangerouslySetInnerHTML: { __html: title } }),
      paragraph && /* @__PURE__ */ jsx("p", { dangerouslySetInnerHTML: { __html: paragraph } }),
      buttons && buttons.length > 0 && /* @__PURE__ */ jsx(ButtonsWrapper, { children: buttons.map((button, index) => {
        return /* @__PURE__ */ jsx(
          Button,
          {
            link: button.link,
            variant: button.variant,
            children: button.text
          },
          index
        );
      }) })
    ] }) }),
    image && /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(TextImageFigure, { children: displayImage }) })
  ] });
};

const Hero = ({ heroType, children, content }) => {
  if (!children && !content) {
    return null;
  }
  let HeroTypeOutput;
  switch (heroType) {
    case "center":
      HeroTypeOutput = /* @__PURE__ */ jsx(CenterText, { children });
      break;
    case "textImage":
      HeroTypeOutput = /* @__PURE__ */ jsx(TextImage, { ...content });
      break;
  }
  return /* @__PURE__ */ jsx(HeroWrapper, { children: /* @__PURE__ */ jsx(Container, { children: HeroTypeOutput }) });
};

const $$Astro$3 = createAstro("https://agency-aestro-astro.netlify.app/");
const $$About = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$About;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Accionar Chile | Sobre Nosotros", "description": "Conoce nuestra misi\xF3n y visi\xF3n para transformar vidas a trav\xE9s del coaching y el desarrollo personal." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> <!-- Sección de Presentación --> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Sobre Nosotros</h1> <p>
En <b>Accionar Chile</b>, creemos en el potencial ilimitado de cada persona. Nuestra misión es 
                    proporcionar herramientas prácticas de desarrollo personal y fomentar una comunidad colaborativa 
                    orientada a la transformación personal y comunitaria.
</p> ` })} ` })} <!-- Sección Misión --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: `Nuestra Misi\xF3n`,
    paragraph: `
                    Impartimos Programas de Coaching con herramientas pr\xE1cticas de Desarrollo Personal, 
                    para que nuestros clientes logren <b>conectar con su poder interior</b> y vivir en su m\xE1xima posibilidad.  
                    Adem\xE1s, fomentamos una <b>Comunidad Colaborativa Cont\xEDnua</b> enfocada en alcanzar 
                    objetivos tanto personales como comunitarios.
                `,
    image: {
      src: "https://picsum.photos/630/400?random=2",
      alt: "Imagen Misi\xF3n Accionar Chile",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} <!-- Sección Visión --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `Nuestra Visi\xF3n`,
    paragraph: `
                    Nuestra visi\xF3n es <b>elevar el Nivel de Consciencia en el Mundo</b>, 
                    inspirando a las personas a descubrir su verdadero potencial y transformar sus vidas.
                    Creemos en un mundo donde cada persona pueda conectar con su poder y vivir en su m\xE1xima posibilidad.
                `,
    image: {
      src: "https://picsum.photos/630/400?random=3",
      alt: "Imagen Visi\xF3n Accionar Chile",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} <!-- Sección Valores de Accionar Chile --> <section id="values"> ${renderComponent($$result2, "Container", Container, {}, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h2>Nuestros Valores</h2> ` })} ` })} ${renderComponent($$result2, "BoxOffers", BoxOffers, { "client:load": true, "boxes": [
    {
      content: `
                        <h2>Crecimiento Personal</h2>
                        <p>Facilitamos el desarrollo de habilidades que potencian la transformaci\xF3n personal y profesional.</p>
                        `
    },
    {
      content: `
                        <h2>Comunidad y Colaboraci\xF3n</h2>
                        <p>Creemos en el poder del apoyo mutuo para alcanzar metas individuales y colectivas.</p>
                        `
    },
    {
      content: `
                        <h2>Conciencia y Evoluci\xF3n</h2>
                        <p>Promovemos un enfoque consciente en la vida y el trabajo para lograr cambios significativos.</p>
                        `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/BoxOffers", "client:component-export": "BoxOffers" })} </section> <!-- Sección Redes Sociales --> ${renderComponent($$result2, "Container", Container, {}, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h2>Conéctate con nosotros</h2> <p>Síguenos en nuestras redes sociales para conocer más sobre nuestra comunidad y eventos.</p> ` })} ` })} ${renderComponent($$result2, "BoxOffers", BoxOffers, { "client:load": true, "boxes": [
    {
      asLink: true,
      href: "https://www.facebook.com",
      content: `
                        <h3>Facebook</h3>
                    `
    },
    {
      asLink: true,
      href: "https://www.linkedin.com/c",
      content: `
                        <h3>LinkedIn</h3>
                    `
    },
    {
      asLink: true,
      href: "https://www.twitter.com",
      content: `
                        <h3>Twitter</h3>
                    `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/BoxOffers", "client:component-export": "BoxOffers" })} </main> ` })}`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/about.astro", void 0);

const $$file$3 = "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/about.astro";
const $$url$3 = "/about";

const about = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$About,
  file: $$file$3,
  url: $$url$3
}, Symbol.toStringTag, { value: 'Module' }));

const ContactStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
styled.div`
    max-width: 920px;
    margin: 0 auto;
`;
styled.h2`
    &,
    &:last-child {
        margin-bottom: 90px;
    }
`;
const ContainerStyled = styled(Container)`
    ${MediaQuery.min("xxxl")} {
        max-width: 920px;
    }
`;
const ContactBox = styled.div`
    margin: 40px 0;
`;
const ContactThankYou = styled.h2`
    padding: 20px;
    max-width: 800px;
    margin: 0 auto !important;
    box-shadow: 0 0 30px #bc52ee7a;

    ${MediaQuery.max("lg")} {
        font-size: 25px;
        line-height: 30px;
        max-width: 400px;
    }
`;

const Contact = () => {
  const [emailSend, setEmailSend] = useState(false);
  const schema = z.object({
    name: z.string().min(2, {
      message: "Name should be at least 2 characters"
    }),
    email: z.string().email({
      message: "Please enter a valid email"
    }),
    message: z.string().min(10, {
      message: "Message should be at least 10 characters"
    })
  });
  const contactForm = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      email: "",
      message: ""
    }
  });
  const formSubmit = contactForm.handleSubmit(async (values) => {
    const response = await fetch("https://formsubmit.co/jocsan.riquelme.m@gmail.com", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values)
    });
    if (response.ok) {
      setEmailSend(true);
    } else {
      console.error("Error sending form");
    }
  });
  return /* @__PURE__ */ jsx(ContactStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled, { children: [
    !emailSend ? /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(FormStyled, { onSubmit: formSubmit, children: [
      /* @__PURE__ */ jsxs("h2", { children: [
        "¿Tienes alguna pregunta o quieres trabajar junto a nosotros?  ",
        /* @__PURE__ */ jsx("b", { children: "¡Hablemos!" })
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        "Este formulario está desarrollado con ",
        /* @__PURE__ */ jsx("b", { children: "FormSubmit" }),
        "."
      ] }),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "text",
          placeholder: "Nombre *",
          register: contactForm.register("name"),
          error: contactForm.formState.errors.name?.message
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "email",
          placeholder: "Correo Electronico *",
          register: contactForm.register("email"),
          error: contactForm.formState.errors.email?.message
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          type: "textarea",
          placeholder: "Escribienos .... *",
          register: contactForm.register("message"),
          error: contactForm.formState.errors.message?.message
        }
      ),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: contactForm.formState.isSubmitting, children: /* @__PURE__ */ jsx(Button, { asButton: true, variant: "secondary", children: contactForm.formState.isSubmitting ? "Sending..." : "Submit" }) })
    ] }) }) : /* @__PURE__ */ jsx(ContactThankYou, { children: "¡Gracias por tu mensaje! Te responderemos lo antes posible." }),
    /* @__PURE__ */ jsx(ContactBox, { children: /* @__PURE__ */ jsxs(FadeIn, { delay: 0.2, children: [
      /* @__PURE__ */ jsx("h2", { children: "Enviar por correo electrónico" }),
      /* @__PURE__ */ jsx(
        TextBox,
        {
          bgText: "Email",
          boxAsLink: true,
          href: "mailto:jocsan.riquelme.m@gmail.com",
          target: "_blank",
          children: `
                            <h3>Haga Click para enviar correo electrónico.</h3>
                            <p>
                                Usa tu plataforma de correos para contactarte con nosotros
                            </p>
                            `
        }
      )
    ] }) })
  ] }) });
};

const $$Astro$2 = createAstro("https://agency-aestro-astro.netlify.app/");
const $$Contact = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Contact;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Agency Aestro | Offers", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "center", "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Contacto</h1> ` })} ` })} ${renderComponent($$result2, "ContactModule", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ` })}`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/contact.astro", void 0);

const $$file$2 = "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/contact.astro";
const $$url$2 = "/contact";

const contact = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Contact,
  file: $$file$2,
  url: $$url$2
}, Symbol.toStringTag, { value: 'Module' }));

const LogosSliderStyled = styled.section`
    padding: 0;

    ${MediaQuery.max("lg")} {
        padding: 50px 0 0;
    }

    h2 {
        margin-bottom: 50px;
    }

    .swiper .swiper-slide {
        width: calc(100% / 8);

        ${MediaQuery.max("xl")} {
            width: calc(100% / 6);
        }

        ${MediaQuery.max("lg")} {
            width: calc(100% / 4);
        }

        ${MediaQuery.max("md")} {
            width: calc(100% / 3);
        }
    }
`;
const Logo = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;

    img {
        width: 100px;
        height: 100px;
        object-fit: contain;

        [data-theme="dark"] & {
            filter: invert(1);
        }
    }
`;

const LogosSliderData = [
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  },
  {
    logo: IconAstro,
    alt: "astro.build"
  }
];

const SwiperStyled = styled(Swiper)`
    overflow: hidden;
    width: 100%;

    .swiper-wrapper {
        transition-timing-function: linear;

        display: flex;
    }

    /**
     * to customize the slider sizes, use breakpoints in swiper
     * if slidesPerView is set to auto, it will automatically adjust the size of the slides
     * to override the default size, use the following css
     * @example 
     * .swiper-slide {
     *     width: calc(100% / number);
     * }
     * live example on  LogosSlider component
    */
    .swiper-slide {
        width: calc(100% / 4);
    }
`;

const SwiperSlider = ({
  children,
  options,
  modules,
  ...rest
}) => {
  if (!children) {
    return null;
  }
  const memoChildren = useMemo(
    () => React.Children.map(children, (child, index) => /* @__PURE__ */ jsx(SwiperSlide, { className: "splide__slide", children: child }, index)),
    [children]
  );
  return /* @__PURE__ */ jsx(
    SwiperStyled,
    {
      modules,
      slidesPerView: 3,
      speed: 4e3,
      spaceBetween: 30,
      ...options,
      ...rest,
      children: memoChildren
    }
  );
};

const LogosSlider = () => {
  const data = LogosSliderData;
  if (!data || data.length === 0) {
    return null;
  }
  const slides = data.map((slide, index) => /* @__PURE__ */ jsx(Logo, { children: /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(
    Image,
    {
      src: slide.logo.src,
      width: slide.logo.width,
      height: slide.logo.height,
      alt: slide.alt
    }
  ) }) }, index));
  return /* @__PURE__ */ jsx(LogosSliderStyled, { children: /* @__PURE__ */ jsx(
    SwiperSlider,
    {
      modules: [Autoplay],
      options: {
        slidesPerView: "auto",
        loop: true,
        freeMode: true,
        autoplay: {
          delay: 0,
          disableOnInteraction: false
        }
      },
      children: slides
    }
  ) });
};

const $$Astro$1 = createAstro("https://agency-aestro-astro.netlify.app/");
const $$Offers = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Offers;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Programa Sinerg\xE9ticos | Desarrollo Personal y Comunitario", "description": "Descubre el programa Sinerg\xE9ticos y potencia tu crecimiento personal y profesional." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> <!-- Sección de Bienvenida --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "center", "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Bienvenido a <span style="color: #ff8601;">Sinergéticos</span></h1> <p>
Un programa diseñado para potenciar el desarrollo personal y comunitario, 
                    a través de la transformación individual y el trabajo colaborativo.
</p> ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "delay": 0.3, "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` ${renderComponent($$result4, "Button", Button, { "link": "#beneficios", "variant": "secondary" }, { "default": ($$result5) => renderTemplate`
Beneficios
` })} ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "delay": 0.4, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <div class="icon-wrapper"> ${renderComponent($$result4, "Icon", Icon, { "iconData": "arrowDown", "alt": "arrow down icon" })} </div> ` })} ` })} ${renderComponent($$result2, "LogosSlider", LogosSlider, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/LogosSlider", "client:component-export": "LogosSlider" })} <!-- Niveles del Programa --> ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `Primer Nivel: Revisi\xF3n de Creencias Limitantes`,
    paragraph: `Identifica y transforma aquellas creencias que te impiden avanzar. 
                Aprende a reprogramar tu mente y liberar tu m\xE1ximo potencial.`,
    image: {
      src: "https://picsum.photos/630/400?random=1",
      alt: "Imagen Revisi\xF3n de Creencias Limitantes",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    switchPlaces: true,
    title: `Segundo Nivel: Conecta con tu Poder`,
    paragraph: `Descubre tus cualidades esenciales y fortalece tu identidad. 
                Aprende a reconocer el poder que hay en ti para alcanzar tus metas.`,
    image: {
      src: "https://picsum.photos/630/400?random=2",
      alt: "Imagen Conectar con tu Poder",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `Tercer Nivel: Creaci\xF3n y Trabajo Colaborativo`,
    paragraph: `Convierte tus ideas en acciones concretas. Dise\xF1a y realiza objetivos personales 
                y comunitarios a trav\xE9s de una red de apoyo colaborativa.`,
    image: {
      src: "https://picsum.photos/630/400?random=3",
      alt: "Imagen Creaci\xF3n y Trabajo Colaborativo",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} <!-- Beneficios de la Comunidad Sinergéticos --> <section id="beneficios"> ${renderComponent($$result2, "BoxOffers", BoxOffers, { "client:load": true, "boxes": [
    {
      content: `
                        <h2>Programa de acompa\xF1amiento continuo</h2>
                        <p>Sesiones con Coaches profesionales para guiar tu crecimiento personal y profesional.</p>
                        `
    },
    {
      content: `
                        <h2>Capacitaci\xF3n y formaci\xF3n permanente</h2>
                        <p>Acceso a cursos, talleres y mentor\xEDas en diversas \xE1reas de desarrollo personal.</p>
                        `
    },
    {
      content: `
                        <h2>Grupos de estudio y apoyo</h2>
                        <p>Comunidad activa donde recibir\xE1s apoyo para alcanzar tus objetivos.</p>
                        `
    },
    {
      content: `
                        <h2>Directorio de Emprendimientos y Servicios</h2>
                        <p>Con\xE9ctate con una red de profesionales y emprendedores dentro de la comunidad.</p>
                        `
    },
    {
      content: `
                        <h2>Eventos y Networking</h2>
                        <p>Participa en actividades exclusivas dise\xF1adas para fortalecer tus contactos y oportunidades.</p>
                        `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/BoxOffers", "client:component-export": "BoxOffers" })} </section> <!-- Formulario de Contacto --> ${renderComponent($$result2, "Contact", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ` })}`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/offers.astro", void 0);

const $$file$1 = "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/offers.astro";
const $$url$1 = "/offers";

const offers = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Offers,
  file: $$file$1,
  url: $$url$1
}, Symbol.toStringTag, { value: 'Module' }));

const robotsTxt = `
User-agent: *
Allow: /

Sitemap: ${new URL("sitemap-index.xml", "https://agency-aestro-astro.netlify.app/").href}
`.trim();
const GET = () => {
  return new Response(robotsTxt, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8"
    }
  });
};

const robots_txt = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: 'Module' }));

const LeadTextsStyled = styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }
`;
styled.h2`
    &:last-child {
        margin-bottom: 40px;
    }
`;
const LeadTextsContent = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 50px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
    }
`;
const LeadTextsContentText = styled.div`
    display: flex;
    flex-direction: column;
    gap: 150px;

    ${MediaQuery.max("lg")} {
        order: 2;
        gap: 50px;
    }

    h3 {
        font-size: 30px;
        font-weight: 200;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
        }
    }

    h4 {
        font-size: 20px;

        margin-bottom: 5px;

        ${MediaQuery.max("lg")} {
            font-size: 16px;
        }
    }

    p {
        font-size: 16px;
        line-height: 1.7;
        letter-spacing: 0.7px;

        &:not(:last-child) {
            margin-bottom: 40px;
        }
    }

    > div:not(:last-child) {
        ${MediaQuery.max("lg")} {
            border-bottom: 1px solid ${Theme.tertiary};
            padding-bottom: 50px;
            margin-bottom: 0;
        }
    }
`;
const LeadTextsContentTitle = styled.div`
    display: flex;
    justify-content: center;

    > div h2 {
        position: sticky;
        top: 50%;
        display: block;
    }

    img {
        border-radius: 10px;

        border-top-right-radius: 200px;
        border-bottom-left-radius: 200px;

        width: 90%;

        ${MediaQuery.max("lg")} {
            width: 100%;
            max-height: 300px;

            border-top-right-radius: 100px;
            border-bottom-left-radius: 100px;
        }
    }
`;
styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin: 50px 0;

    ${MediaQuery.max("sm")} {
        grid-template-columns: 1fr;
    }
`;
styled.section`
    padding: 100px 0;

    ${MediaQuery.max("lg")} {
        padding: 60px 0;
    }

    h2 br {
        ${MediaQuery.max("sm")} {
            display: none;
        }
    }
`;
styled.div`
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: repeat(2, 1fr);
    }

    ${MediaQuery.max("sm")} {
        grid-template-columns: 1fr;
    }
`;

const LeadTexts = ({ contentText, title }) => {
  if (!contentText && !title) {
    return null;
  }
  return /* @__PURE__ */ jsx(LeadTextsStyled, { children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs(LeadTextsContent, { children: [
    title && /* @__PURE__ */ jsx(LeadTextsContentTitle, { children: /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(
      "h2",
      {
        dangerouslySetInnerHTML: { __html: title }
      }
    ) }) }),
    /* @__PURE__ */ jsx(LeadTextsContentText, { children: contentText.map((content, index) => {
      return /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(
        "div",
        {
          dangerouslySetInnerHTML: {
            __html: content.content
          }
        }
      ) }, index);
    }) })
  ] }) }) });
};

const $$Astro = createAstro("https://agency-aestro-astro.netlify.app/");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Accionar Chile", "description": "Red Colaborativa" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:load": true, "content": {
    title: `Accionar Chile <span style="color: #ff8601;">Coaching</span> que impulsa tu \xE9xito.`,
    paragraph: `\xA1Conecta con Tu Poder! y Vive en Tu M\xE1xima posibilidad!`,
    buttons: [
      {
        link: "#Contacto",
        text: "Cont\xE1ctanos",
        variant: "secondary"
      },
      {
        link: "#Servicios",
        text: "M\xE1s Informaci\xF3n",
        variant: "primary"
      }
    ],
    image: {
      srcLocal: "heroImg",
      alt: "Imagen HomeHero ",
      width: 300,
      height: 300
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "LogosSlider", LogosSlider, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/LogosSlider", "client:component-export": "LogosSlider" })} ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h2>¿Por qué elegirnos?</h2> <p>
No solo te acompañamos en tu crecimiento individual, sino que también fomentamos una comunidad colaborativa donde el aprendizaje y el apoyo mutuo son la clave para lograr objetivos personales y colectivos.
</p> ` })} ` })} <div id="Servicios"> ${renderComponent($$result2, "BoxOffers", BoxOffers, { "client:load": true, "boxes": [
    {
      content: `
                        <h2>Coaching con prop\xF3sito</h2>
                        <p>Te guiamos en un proceso de transformaci\xF3n real y significativo.</p>
                        `
    },
    {
      content: `
                        <h2>Herramientas pr\xE1cticas</h2>
                        <p>T\xE9cnicas aplicables a tu vida diaria para potenciar tu desarrollo.</p>
                        `
    },
    {
      content: `
                        <h2>Acompa\xF1amiento continuo</h2>
                        <p>No est\xE1s solo en este camino; formamos parte de tu evoluci\xF3n.</p>
                        `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/BoxOffers", "client:component-export": "BoxOffers" })} </div> ${renderComponent($$result2, "LeadTexts", LeadTexts, { "client:load": true, "title": "Nuestros Servicios", "contentText": [
    {
      content: `
                        <h3>
                            <b>Programa de Coaching para adolescentes</b> - Acompa\xF1amiento y desarrollo personal para potenciar habilidades, seguridad y toma de decisiones en j\xF3venes.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Escuela para padres</b> - Herramientas efectivas para fortalecer la comunicaci\xF3n y la crianza consciente en la familia.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Programa de Coaching para emprendedores y networking</b> - Estrategias y mentor\xEDa para impulsar negocios, fortalecer habilidades y crear conexiones valiosas.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Organizaci\xF3n de grandes eventos con conferencistas internacionales</b> - Eventos exclusivos con expertos de talla mundial en desarrollo personal y profesional.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Programas de coaching para empresas</b> - Capacitaci\xF3n y desarrollo de equipos para mejorar el liderazgo, la productividad y el bienestar organizacional.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Programa de Coaching para personas de la tercera edad</b> - Acompa\xF1amiento para redescubrir nuevas oportunidades, fortalecer el bienestar y la calidad de vida en esta etapa.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Coaching para parejas</b> - Mejora de la comunicaci\xF3n, resoluci\xF3n de conflictos y fortalecimiento del v\xEDnculo en la relaci\xF3n.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Escuela para entrenadores</b> - Formaci\xF3n especializada para quienes desean convertirse en coaches profesionales y guiar a otros en su transformaci\xF3n.
                        </h3>
                    `
    },
    {
      content: `
                        <h3>
                            <b>Talleres de Inteligencia Financiera</b> - Educaci\xF3n y estrategias pr\xE1cticas para una gesti\xF3n financiera consciente y efectiva.
                        </h3>
                    `
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/LeadTexts", "client:component-export": "LeadTexts" })} <div id="Contacto">${renderComponent($$result2, "Contact", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })}</div> </main> ` })}`;
}, "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/index.astro", void 0);

const $$file = "/Users/jajajajja/Desktop/Accionar-chile-page/src/pages/index.astro";
const $$url = "";

const index = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

export { _404 as _, about as a, contact as c, index as i, offers as o, robots_txt as r };
